import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, TextInput} from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <View>
        <Image source={require("./assets/pingu.png")}
          style={styles.image}
        />

        
      </View>
      <TextInput
          style={styles.textInput}
          placeholder="Entre com seu nome"
        />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
  },
  image: {
    resizeMode: 'center',

  },
  textInput: {
    height: 40,
    width: 390,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 10,
    margin: 20,
  }
});
